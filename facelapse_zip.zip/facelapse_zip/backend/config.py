import os

class Config:
    """Base configuration."""
    UPLOAD_FOLDER = 'uploads'