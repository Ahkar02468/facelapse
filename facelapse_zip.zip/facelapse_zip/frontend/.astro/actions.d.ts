declare module "astro:actions" {
	type Actions = typeof import("/home/ahkartg/facelapse/frontend/src/actions")["server"];

	export const actions: Actions;
}