declare module 'astro:assets' {
	/** @internal */
	export type FontFamily = (["--font-geist"])[number];
}
