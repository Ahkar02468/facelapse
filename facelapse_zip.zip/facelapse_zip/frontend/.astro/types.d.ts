/// <reference types="astro/client" />
/// <reference path="fonts.d.ts" />